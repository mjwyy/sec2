package presentation.logisticui;
/*
 *中转中心装车单
 *@author wwz
 *@date 10/26
 */
import businesslogicservice.logisticblservice.LoadNoteOnTransitBLService;

public class LoadNoteOnTransitUI {
        public void init(LoadNoteOnTransitBLService service){
        	
        }
}
