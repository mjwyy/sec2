package data.financedata.MockObject;


import po.PaymentPO;

public class MockPaymentInput extends PaymentPO{
	String date;
	public MockPaymentInput(String date) {
		this.date=date;
	}

}
