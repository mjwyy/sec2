/**
 * 审批单据界面
 * @author wqy
 * @date 2015/10/17
 */
package presentation.statisticui;

import businesslogicservice.statisticblservice.NoteApprovingBLService;

public class NoteApprovingUI {
	
	public NoteApprovingUI(NoteApprovingBLService service){
		
	}
}
