package presentation.logisticui;
/**
 * 输入寄件单
 * @author wwz
 * @data 2015/10/26
 *
 */
import businesslogicservice.logisticblservice.DeliveryNoteInputBLService;


public class DeliveryNoteInputUI {
	public void init(DeliveryNoteInputBLService service){

	}
	

}
