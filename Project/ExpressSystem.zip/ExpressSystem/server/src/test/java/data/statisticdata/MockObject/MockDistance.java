package data.statisticdata.MockObject;

import po.DistancePO;

public class MockDistance extends DistancePO {

	public MockDistance(String city1, String city2, double d) {
		super(city1, city2, d);
	}

}
