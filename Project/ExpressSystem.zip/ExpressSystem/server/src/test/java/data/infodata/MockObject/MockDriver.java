package data.infodata.MockObject;

import po.DriverPO;

public class MockDriver extends DriverPO{

	public MockDriver(String driverNumber, String name, String birthday,
			String iDCardNumber, String phoneNumber, String gender,
			String licenseDate) {
		super(driverNumber, name, birthday, iDCardNumber, phoneNumber, gender,
				licenseDate);
		// TODO Auto-generated constructor stub
	}

}
