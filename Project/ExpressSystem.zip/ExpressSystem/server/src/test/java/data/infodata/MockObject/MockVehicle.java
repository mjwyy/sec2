package data.infodata.MockObject;

import java.io.File;

import po.VehiclePO;

public class MockVehicle extends VehiclePO{

	public MockVehicle(String carNumber, String hallNumber, File picture,
			String firstUseTime) {
		super(carNumber, hallNumber, picture, firstUseTime);
		// TODO Auto-generated constructor stub
	}

}
