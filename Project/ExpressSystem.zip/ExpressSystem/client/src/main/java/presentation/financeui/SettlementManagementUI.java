/**
 * 结算管理UI
 * @author River
 */
package presentation.financeui;

import businesslogicservice.financeblservice.SettlementManagementBLService;

/**
 * @author River
 * 前置条件：用户选择结算管理的功能
 * 后置条件：显示此界面
 */
public class SettlementManagementUI {
	
	public SettlementManagementUI(SettlementManagementBLService logic) {
		
	}

}
