/**
 * 管理银行账户UI
 * @author River
 */
package presentation.financeui;

import businesslogicservice.infoblservice.BankAccountManagementBLService;

/**
 * @author River
 * 前置条件：用户选择管理银行账户功能
 * 后置条件：显示本界面
 */
public class BankAccountManagementUI {
	
	public BankAccountManagementUI(BankAccountManagementBLService logic){
		
	}
}
