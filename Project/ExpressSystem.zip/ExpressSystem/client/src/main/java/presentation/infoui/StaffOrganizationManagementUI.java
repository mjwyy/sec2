/**
 * 人员机构管理界面
 * @author wqy
 * @date 2015/10/17
 */
package presentation.infoui;

import businesslogicservice.infoblservice.StaffOrganizationManagementBLService;

public class StaffOrganizationManagementUI {
	
	public StaffOrganizationManagementUI(StaffOrganizationManagementBLService service){
		
	}
}
