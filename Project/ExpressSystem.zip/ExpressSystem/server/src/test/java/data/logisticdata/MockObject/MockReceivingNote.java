package data.logisticdata.MockObject;

import po.ReceivingNotePO;

/**
 * Created by kylin on 15/11/12.
 */
public class MockReceivingNote extends ReceivingNotePO {
    public MockReceivingNote(String barcode, String receiveCustomer, String time) {
        super(barcode, receiveCustomer, time);
    }
}
