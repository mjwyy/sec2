package dataservice.exception;

/**
* @author River
*/
public class ElementNotFoundException extends Exception {


	private static final long serialVersionUID = -4080377879461286908L;

	
}
