package presentation.logisticui;

import businesslogicservice.logisticblservice.ArrivalNoteOnServiceBLService;

public class ArrivalNoteOnServiceUI {

	public ArrivalNoteOnServiceUI(ArrivalNoteOnServiceBLService service){}
	
}
