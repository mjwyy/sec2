package presentation.statisticui;

import businesslogicservice.statisticblservice.BusinessDataModificationBLService;

public class BusinessDataModificationUI {

	public BusinessDataModificationUI(BusinessDataModificationBLService service){}
	
}
