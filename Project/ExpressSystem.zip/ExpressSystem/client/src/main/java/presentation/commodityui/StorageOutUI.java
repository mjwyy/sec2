/**
 * 库存出库单界面
 * @author wqy
 * @date 2015/10/17
 */
package presentation.commodityui;

import businesslogicservice.commodityblservice.StorageOutBLService;

public class StorageOutUI {
	
	public StorageOutUI(StorageOutBLService service){
		
	}
}
