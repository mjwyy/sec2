package util.enums;

public enum InventoryStatus {
	SAFE,
	DANGER

}
