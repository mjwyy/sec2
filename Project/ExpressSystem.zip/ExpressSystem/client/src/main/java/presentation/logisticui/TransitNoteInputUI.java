package presentation.logisticui;
/*
 *中转单处理
 *@author wwz
 *@date 10/26
 */
import businesslogicservice.logisticblservice.TransitNoteInputBLService;

public class TransitNoteInputUI {
    public void init(TransitNoteInputBLService service){
    	
    }
}
