package presentation.commodityui;

import businesslogicservice.commodityblservice.StorageInquiryAllBLService;

public class StorageInquiryAllUI {
	
	public StorageInquiryAllUI(StorageInquiryAllBLService service){
		
	}

}
