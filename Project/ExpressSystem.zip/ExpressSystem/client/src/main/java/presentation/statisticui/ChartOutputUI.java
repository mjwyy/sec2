package presentation.statisticui;

import businesslogicservice.statisticblservice.ChartOutputBLService;
/**
 * @author River
 * 前置条件：用户选择获取统计报表的功能
 * 后置条件：显示此界面
 */
public class ChartOutputUI {

	public ChartOutputUI(ChartOutputBLService logic) {
		
	}
	
}
