package presentation.infoui;

import businesslogicservice.infoblservice.SystemUserManagementBLService;

public class SystemUserManagementUI {
	
	public SystemUserManagementUI(SystemUserManagementBLService service){
		
	}

}
