/**
 * 库存入库单界面
 * @author wqy
 * @date 2015/10/17
 */
package presentation.commodityui;

import businesslogicservice.commodityblservice.StorageInBLService;

public class StorageInUI {
	
	public StorageInUI(StorageInBLService service){
		
	}
}
