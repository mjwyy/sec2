package presentation.logisticui;
/*
 *@author wwz
 *@date 10/26
 *输入寄件单
 */
import businesslogicservice.logisticblservice.ReceivingNoteInputBLService;

public class ReceivingNoteInputUI {
	public void init(ReceivingNoteInputBLService service){
		
	}

}
