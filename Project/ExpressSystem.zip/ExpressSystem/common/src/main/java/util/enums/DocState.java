package util.enums;

public enum DocState {
	NONCHECKED, // 未审批
	PASSED, //通过
	FAILED // 不通过
}
