package presentation.financeui;

import businesslogicservice.financeblservice.CreditNoteInputBLService;

public class CreditNoteInputUI {
	
	public CreditNoteInputUI(CreditNoteInputBLService service){}

}
