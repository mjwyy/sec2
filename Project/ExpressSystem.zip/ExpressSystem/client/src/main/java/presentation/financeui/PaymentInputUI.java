/**
 * 新增付款记录
 * @author River
 * @date 2015/10/17
 */
package presentation.financeui;

import businesslogicservice.financeblservice.PaymentInputBLService;

/**
 * @author River
 * 前置条件：用户选择新增付款记录的功能
 * 后置条件：显示此界面
 */
public class PaymentInputUI {
	
	public PaymentInputUI(PaymentInputBLService logic) {
		
	}

}
