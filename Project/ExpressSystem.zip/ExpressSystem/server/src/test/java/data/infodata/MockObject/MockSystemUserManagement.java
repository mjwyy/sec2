package data.infodata.MockObject;

import po.UserPO;

public class MockSystemUserManagement extends UserPO{
String account ;

	public MockSystemUserManagement(String account){
		this.account=account;
	}
}
