package connection;

/**
 * Created by kylin on 15/11/10.
 */
public interface RMIObjectProviderService {
    public Object getObjectByName(String name);
}
