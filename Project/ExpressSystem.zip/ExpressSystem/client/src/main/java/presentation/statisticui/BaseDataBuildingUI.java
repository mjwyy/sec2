package presentation.statisticui;

import businesslogicservice.statisticblservice.BaseDataBuildingBLService;

/**
 * 前置条件：用户选择期初建账的功能
 * 后置条件：显示此界面
 */
public class BaseDataBuildingUI {
	
	public BaseDataBuildingUI(BaseDataBuildingBLService logic) {
		
	}
}
