package dataservice.exception;

public class FailToPassApprovingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9014950606252436172L;

}
