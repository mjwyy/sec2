package util.enums;

public enum DeliveryState {
	Embraced,
	Sending,
	Received
}
