package presentation.statisticui;

import businesslogicservice.statisticblservice.LogInquiryBLService;

/**
 * 前置条件：用户选择查询系统日志的功能
 * 后置条件：显示此界面
 */
public class LogInquiryUI {
	
	public LogInquiryUI(LogInquiryBLService logic){
		
	}
	
}
