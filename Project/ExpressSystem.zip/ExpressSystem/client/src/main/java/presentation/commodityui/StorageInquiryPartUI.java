package presentation.commodityui;

import businesslogicservice.commodityblservice.StorageInquiryPartBLService;

public class StorageInquiryPartUI {

	public StorageInquiryPartUI(StorageInquiryPartBLService service) {
		
	}
	
}
