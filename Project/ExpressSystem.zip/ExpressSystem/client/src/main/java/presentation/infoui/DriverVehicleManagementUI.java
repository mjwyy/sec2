package presentation.infoui;

import businesslogicservice.infoblservice.DriverVehicleManagementBLService;

public class DriverVehicleManagementUI {

	public DriverVehicleManagementUI(DriverVehicleManagementBLService service){}
	
}
