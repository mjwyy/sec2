package presentation.logisticui;
/*
 *中转中心到达单
 *@author wwz
 *@date 10/26
 */
import businesslogicservice.logisticblservice.ArrivalNoteOnTransitBLService;

public class ArrivalNoteOnTransitUI {
	
	public void init(ArrivalNoteOnTransitBLService service){
		
	}

}
