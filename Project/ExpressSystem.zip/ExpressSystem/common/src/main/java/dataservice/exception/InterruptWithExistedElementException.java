package dataservice.exception;

public class InterruptWithExistedElementException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8599232482940770326L;

}
