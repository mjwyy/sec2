package presentation.logisticui;

import businesslogicservice.logisticblservice.LoadNoteOnServiceBLService;

public class LoadNoteOnServiceUI {

	public LoadNoteOnServiceUI(LoadNoteOnServiceBLService service ){}
	
}
