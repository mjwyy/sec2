package presentation.mainui;

public class MainFrame {

	public void init(){
		
	}
	
}
